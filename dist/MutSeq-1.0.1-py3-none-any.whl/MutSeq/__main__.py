from .MutSeq import main
main()
